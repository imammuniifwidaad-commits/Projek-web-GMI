// Salin menjadi config.js lalu isi nilai dari Supabase Project Settings > API.
// Jangan pernah memasukkan service_role key atau secret API provider di file ini.
window.GMI_CONFIG = {
  SUPABASE_URL: 'https://YOUR_PROJECT.supabase.co',
  SUPABASE_ANON_KEY: 'YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY',
  MARKET_FUNCTION_URL: 'https://YOUR_PROJECT.supabase.co/functions/v1/market-data'
};
