import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
const cfg = window.GMI_CONFIG || {};
const configured = cfg.SUPABASE_URL?.startsWith('https://') && !cfg.SUPABASE_URL.includes('YOUR_PROJECT') && cfg.SUPABASE_ANON_KEY && !cfg.SUPABASE_ANON_KEY.includes('YOUR_');
const statusEl = document.getElementById('connectionStatus');
let supabase = null;
if (configured) {
  supabase = createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY, { auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true } });
  statusEl.textContent = 'Supabase siap dihubungkan';
  statusEl.style.color = '#00d68f';
} else {
  statusEl.textContent = 'Setup diperlukan · Supabase belum dikonfigurasi';
}
const byId = id => document.getElementById(id);
function notify(message) { if (typeof window.toast === 'function') window.toast(message); else alert(message); }
function showPage(id) { if (typeof window.showPage === 'function') window.showPage(id); }
function friendlyError(error) {
  const msg = error?.message || 'Terjadi kesalahan. Coba lagi.';
  if (/invalid login credentials/i.test(msg)) return 'Email atau password salah.';
  if (/user already registered/i.test(msg)) return 'Email ini sudah terdaftar. Silakan login.';
  if (/email not confirmed/i.test(msg)) return 'Email belum diverifikasi. Periksa inbox kamu.';
  return msg;
}
function goDashboard(user) {
  const meta = user?.user_metadata || {};
  window.currentUser = meta.full_name || user?.email?.split('@')[0] || 'GMI Member';
  if (typeof window.enterDashboard === 'function') window.enterDashboard();
  byId('userDisplay').textContent = window.currentUser;
  showPage('dashboardPage');
  loadLiveMarket();
}
byId('registerForm').addEventListener('submit', async e => {
  e.preventDefault();
  if (!supabase) return notify('Hubungkan Supabase terlebih dahulu. Ikuti README_SETUP.md.');
  const fullName = byId('fullName').value.trim();
  const email = byId('registerEmail').value.trim();
  const username = byId('username').value.trim();
  const password = byId('registerPassword').value;
  if (password !== byId('confirmPassword').value) return notify('Password dan konfirmasi password belum sama.');
  if (!byId('terms').checked) return notify('Setujui Terms of Service dan Privacy Policy.');
  const btn = e.submitter; if (btn) { btn.disabled = true; btn.textContent = 'Membuat akun…'; }
  try {
    const { data, error } = await supabase.auth.signUp({ email, password, options: { data: { full_name: fullName, username }, emailRedirectTo: `${location.origin}${location.pathname}` } });
    if (error) throw error;
    byId('verifyAddress').textContent = email;
    showPage('verifyPage');
    notify(data.session ? 'Akun dibuat. Selamat datang di GMI.' : 'Akun dibuat. Silakan verifikasi melalui email kamu.');
  } catch (err) { notify(friendlyError(err)); }
  finally { if (btn) { btn.disabled = false; btn.textContent = 'Create Account'; } }
});
byId('loginForm').addEventListener('submit', async e => {
  e.preventDefault();
  if (!supabase) return notify('Hubungkan Supabase terlebih dahulu. Ikuti README_SETUP.md.');
  const identity = byId('loginIdentity').value.trim();
  if (!identity.includes('@')) return notify('Untuk saat ini, login menggunakan alamat email. Login username bisa ditambahkan melalui endpoint backend khusus.');
  const btn = e.submitter; if (btn) { btn.disabled = true; btn.textContent = 'Memverifikasi…'; }
  try {
    const { data, error } = await supabase.auth.signInWithPassword({ email: identity, password: byId('loginPassword').value });
    if (error) throw error;
    goDashboard(data.user);
  } catch (err) { notify(friendlyError(err)); }
  finally { if (btn) { btn.disabled = false; btn.textContent = 'Login　➜'; } }
});
byId('googleBtn').addEventListener('click', async () => {
  if (!supabase) return notify('Hubungkan Supabase terlebih dahulu. Ikuti README_SETUP.md.');
  const { error } = await supabase.auth.signInWithOAuth({ provider: 'google', options: { redirectTo: location.origin + location.pathname } });
  if (error) notify(friendlyError(error));
});
byId('forgotForm').addEventListener('submit', async e => {
  e.preventDefault();
  if (!supabase) return notify('Hubungkan Supabase terlebih dahulu. Ikuti README_SETUP.md.');
  const email = e.currentTarget.querySelector('input[type=email]').value.trim();
  const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo: location.origin + location.pathname });
  byId('forgotMessage').textContent = error ? friendlyError(error) : 'Jika email terdaftar, tautan reset password akan dikirim. Periksa inbox dan folder spam.';
});
byId('resendEmail').addEventListener('click', async () => {
  if (!supabase) return notify('Hubungkan Supabase terlebih dahulu.');
  const email = byId('verifyAddress').textContent.trim();
  const { error } = await supabase.auth.resend({ type: 'signup', email });
  notify(error ? friendlyError(error) : 'Permintaan email verifikasi dikirim ulang. Periksa inbox dan spam.');
});
byId('openEmail').addEventListener('click', () => { const email = byId('verifyAddress').textContent.trim(); location.href = email.includes('@') ? 'mailto:' + email : 'mailto:'; });
// Start with a restored session when a visitor returns.
if (supabase) {
  supabase.auth.getSession().then(({ data }) => { if (data.session?.user) goDashboard(data.session.user); });
  supabase.auth.onAuthStateChange((event, session) => {
    if (event === 'SIGNED_IN' && session?.user) goDashboard(session.user);
  });
}
// The frontend only calls our Edge Function. The market provider secret remains server-side.
const marketMap = {
  Indices: [{s:'QQQ',n:'NASDAQ 100 ETF',i:'▤'}, {s:'SPY',n:'S&P 500 ETF',i:'▥'}, {s:'DXY',n:'US Dollar Index',i:'💱'}],
  Forex: [{s:'EUR/USD',n:'EUR/USD',i:'€'}, {s:'GBP/USD',n:'GBP/USD',i:'£'}, {s:'USD/JPY',n:'USD/JPY',i:'¥'}, {s:'AUD/USD',n:'AUD/USD',i:'A'}],
  Commodities: [{s:'XAU/USD',n:'Gold (XAU/USD)',i:'🥇'}, {s:'XAG/USD',n:'Silver (XAG/USD)',i:'◉'}, {s:'WTI',n:'WTI Crude',i:'🛢'}, {s:'BRENT',n:'Brent Crude',i:'🛢'}],
  Crypto: [{s:'BTC/USD',n:'Bitcoin',i:'₿'}, {s:'ETH/USD',n:'Ethereum',i:'◆'}, {s:'SOL/USD',n:'Solana',i:'◎'}, {s:'BNB/USD',n:'BNB',i:'◆'}]
};
let liveCache = {};
async function loadLiveMarket(type = 'Indices') {
  if (!configured || !cfg.MARKET_FUNCTION_URL || cfg.MARKET_FUNCTION_URL.includes('YOUR_PROJECT')) return;
  const items = marketMap[type] || marketMap.Indices;
  try {
    const { data: { session } } = await supabase.auth.getSession();
    const res = await fetch(cfg.MARKET_FUNCTION_URL, { method:'POST', headers:{'Content-Type':'application/json','apikey':cfg.SUPABASE_ANON_KEY, ...(session?.access_token ? {'Authorization':'Bearer '+session.access_token} : {})}, body:JSON.stringify({ symbols:items.map(x=>x.s) }) });
    if (!res.ok) throw new Error('Market API tidak tersedia ('+res.status+').');
    const result = await res.json();
    if (!result.quotes) throw new Error(result.error || 'Format data pasar tidak valid.');
    liveCache[type] = result.quotes;
    renderLiveRows(type, items, result.quotes);
    statusEl.textContent = 'Market API terhubung'; statusEl.style.color = '#00d68f';
  } catch (err) { statusEl.textContent = 'Market data fallback · ' + err.message; statusEl.style.color = '#e9bd69'; }
}
function renderLiveRows(type, items, quotes) {
  const normalized = items.map(x => { const q=quotes[x.s]||{}; const price=Number(q.price); const change=Number(q.changePercent); return [x.n, Number.isFinite(price)&&q.price!==null?price.toLocaleString('en-US',{maximumFractionDigits:4}):'—', Number.isFinite(change)&&q.changePercent!==null?(change>=0?'+':'')+change.toFixed(2)+'%':'—', x.i]; });
  if (normalized.every(row=>row[1]==='—')) return;
  byId('overviewRows').innerHTML = normalized.map(([n,v,p,ico]) => `<div class="market-row"><div class="asset"><span class="coin">${ico}</span><strong>${n}</strong></div><span>${v}</span><b class="${p.startsWith('+')?'positive':p.startsWith('-')?'negative':''}">${p}</b></div>`).join('');
}
document.querySelectorAll('#marketTabs button').forEach(btn => btn.addEventListener('click', () => loadLiveMarket(btn.dataset.market)));
