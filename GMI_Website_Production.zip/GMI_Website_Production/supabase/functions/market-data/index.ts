import { serve } from 'https://deno.land/std@0.224.0/http/server.ts';
const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type', 'Access-Control-Allow-Methods': 'POST, OPTIONS', 'Content-Type': 'application/json' };
const ALLOWED = new Set(['QQQ','SPY','DXY','EUR/USD','GBP/USD','USD/JPY','AUD/USD','XAU/USD','XAG/USD','WTI','BRENT','BTC/USD','ETH/USD','SOL/USD','BNB/USD']);
serve(async req => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return new Response(JSON.stringify({error:'Method not allowed'}), {status:405,headers:cors});
  const apiKey = Deno.env.get('TWELVE_DATA_API_KEY');
  if (!apiKey) return new Response(JSON.stringify({error:'TWELVE_DATA_API_KEY belum diatur sebagai Supabase secret.'}), {status:503,headers:cors});
  try {
    const body = await req.json();
    const symbols = Array.isArray(body.symbols) ? [...new Set(body.symbols.filter((s:unknown): s is string => typeof s === 'string' && ALLOWED.has(s)))].slice(0,8) : [];
    if (!symbols.length) return new Response(JSON.stringify({error:'Tidak ada simbol yang diizinkan.'}), {status:400,headers:cors});
    // Parallel requests; provider quotas apply. Keep API key exclusively on the server.
    const entries = await Promise.all(symbols.map(async symbol => {
      const url = new URL('https://api.twelvedata.com/quote'); url.searchParams.set('symbol',symbol); url.searchParams.set('apikey',apiKey);
      const response = await fetch(url); const q = await response.json();
      if (!response.ok || q.status === 'error' || q.code) return [symbol, {error:q.message || 'Provider tidak mengembalikan data.'}];
      const price = Number(q.close || q.price);
      const changePercent = Number(q.percent_change);
      return [symbol, { price:Number.isFinite(price)?price:null, changePercent:Number.isFinite(changePercent)?changePercent:null, currency:q.currency || null, timestamp:q.datetime || null }];
    }));
    return new Response(JSON.stringify({quotes:Object.fromEntries(entries), updatedAt:new Date().toISOString(), source:'Twelve Data'}), {headers:{...cors,'Cache-Control':'public, max-age=20'}});
  } catch (_e) { return new Response(JSON.stringify({error:'Permintaan market data tidak valid.'}), {status:400,headers:cors}); }
});
