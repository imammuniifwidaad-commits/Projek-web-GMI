# GMI — production starter (Supabase + Twelve Data)

Website ini melanjutkan prototype GMI dengan desain navy/emas. Login, pendaftaran, reset password, verifikasi email, Google OAuth, profil pengguna, dan endpoint data pasar dihubungkan ke layanan backend setelah konfigurasi dilakukan.

## Stack yang disarankan
- **Supabase Auth + Postgres**: email/password, email verification, reset password, profil pengguna dan RLS.
- **Supabase Edge Function**: proxy server-side agar kunci penyedia harga tidak terekspos ke browser.
- **Twelve Data**: harga pasar. Ketersediaan simbol, real-time/delay, dan batas request tergantung paket/izin akun.
- **Hosting statis**: Netlify, Vercel, Cloudflare Pages, atau hosting web yang mendukung HTTPS.

## Setup lokal
1. Buat proyek di Supabase.
2. Buka `supabase/schema.sql`, jalankan seluruh SQL di Supabase SQL Editor.
3. Salin `config.example.js` menjadi `config.js` dan isi `SUPABASE_URL`, `SUPABASE_ANON_KEY`, serta `MARKET_FUNCTION_URL` dari proyek kamu. `config.js` diabaikan oleh Git.
4. Di Supabase > Authentication > URL Configuration, set Site URL ke URL hosting kamu dan tambahkan URL lokal/development ke Redirect URLs. Untuk lokal, gunakan server statis (mis. `npx serve .`) daripada membuka file langsung.
5. Di Authentication > Providers, aktifkan Email. Atur SMTP produksi sebelum peluncuran publik agar email verifikasi/reset terkirim dengan andal.
6. Jika memakai Google Login, aktifkan provider Google di Supabase dan isi Client ID/Secret dari Google Cloud Console. Tambahkan callback URL yang ditampilkan Supabase di Google Cloud Console.
7. Install Supabase CLI, login, lalu tautkan proyek:
   ```bash
   supabase login
   supabase link --project-ref YOUR_PROJECT_REF
   supabase secrets set TWELVE_DATA_API_KEY=YOUR_TWELVE_DATA_API_KEY
   supabase functions deploy market-data
   ```
8. Tambahkan `config.js` ke root folder deploy. Jangan mengunggah `service_role` key, database password, atau Twelve Data API key ke frontend/repository.
9. Uji alur: daftar dengan email nyata → klik verifikasi → login → reset password → uji market endpoint. Konfigurasikan domain dan HTTPS sebelum rilis.

## Keamanan dan batasan yang perlu diketahui
- Supabase anon/publishable key memang digunakan di frontend; keamanan data harus ditegakkan dengan RLS dan konfigurasi Auth.
- **Jangan gunakan service_role key di browser.**
- Edge Function ini membatasi simbol yang boleh diminta, tetapi untuk produksi sebaiknya tambahkan rate limiting, cache server-side, monitoring, dan validasi sesi/JWT yang sesuai kebutuhan akses.
- Login menggunakan email/password. Username disimpan sebagai profil, tetapi login dengan username belum aktif; itu membutuhkan endpoint backend yang aman untuk lookup username.
- Google OAuth memerlukan konfigurasi manual di Supabase dan Google Cloud.
- Endpoint contoh memanggil quote per simbol; batas API penyedia dapat menyebabkan sebagian quote gagal. Sesuaikan simbol dengan paket dan endpoint yang tersedia. DXY, indeks dan komoditas tertentu bisa memerlukan simbol/provider/izin berbeda.
- Data berita, kalender ekonomi, portfolio, dan notifikasi masih placeholder. Integrasi provider terpisah diperlukan untuk data berita/kalender yang nyata.
- Sebelum produksi: tambahkan rate limiting, monitoring, backup, kebijakan privasi, terms, dan pengujian keamanan.

## Struktur
- `index.html` — UI GMI responsive berdasarkan desain referensi.
- `app.js` — integrasi Supabase Auth dan pemanggilan fungsi market-data.
- `config.example.js` — contoh konfigurasi frontend; salin menjadi `config.js`.
- `supabase/schema.sql` — tabel profil, trigger, dan Row Level Security.
- `supabase/functions/market-data/index.ts` — proxy quote ke Twelve Data.
